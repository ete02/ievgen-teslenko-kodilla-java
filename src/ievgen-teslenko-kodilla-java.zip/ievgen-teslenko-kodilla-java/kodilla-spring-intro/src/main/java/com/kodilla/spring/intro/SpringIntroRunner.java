package com.kodilla.spring.intro;

public class SpringIntroRunner {
    public static void main(String[] args) {
        System.out.println("Welcome into the intro to spring");
    }
}
