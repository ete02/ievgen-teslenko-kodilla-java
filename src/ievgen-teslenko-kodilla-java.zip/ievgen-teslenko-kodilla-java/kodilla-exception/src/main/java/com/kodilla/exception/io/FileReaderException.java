package com.kodilla.exception.io;

public class FileReaderException extends Exception {

}