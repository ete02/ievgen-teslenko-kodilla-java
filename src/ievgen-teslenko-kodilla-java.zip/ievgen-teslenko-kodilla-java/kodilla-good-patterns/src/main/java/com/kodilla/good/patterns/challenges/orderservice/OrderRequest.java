package com.kodilla.good.patterns.challenges.orderservice;

public interface OrderRequest {
}
