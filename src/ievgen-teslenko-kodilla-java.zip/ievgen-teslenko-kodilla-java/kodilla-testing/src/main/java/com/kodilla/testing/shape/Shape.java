package com.kodilla.testing.shape;

public interface Shape {
    String getShapeName();

    int getField();
}
