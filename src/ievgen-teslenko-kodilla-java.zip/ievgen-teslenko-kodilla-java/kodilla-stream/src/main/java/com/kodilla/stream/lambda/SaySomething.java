package com.kodilla.stream.lambda;

public class SaySomething {
    public void say() {
        System.out.println("This is an example text.");
    }
}
